Feature: vaidating place API's
@AddPlace
Scenario Outline: Verfiy if plcaed is being added successfullya added using AddPlaceApi
          Given Add place payload with "<name>" "<language>" "<address>"
          When  user call "AddPlaceAPI" with "post" http request
          Then  the api call got sccuess with status code is 200
          And   "status" in response body is "OK"
          And   "scope" in response body is "APP"
Examples:
       |name   |language|address
       |A House|Eng     |New delhi
       |B House|French  |jaipur
@DeletePlace    
 Scenario: Verfiy that if delete place functionality is working
 
        Given DeletePlace Payload
        When  user call "deletePlaceAPI" with "POST" http request
        Then  the API call got success with status code 200
        And   "status" in response body is "OK"
       


