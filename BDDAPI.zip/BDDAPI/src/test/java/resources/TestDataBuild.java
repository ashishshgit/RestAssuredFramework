package resources;

import java.util.ArrayList;
import java.util.List;

import Pojo2.AddPlace;
import Pojo2.location;

public class TestDataBuild {

public AddPlace AddPlcaePayload(String name, String language , String address)

{
	AddPlace ap = new AddPlace();

	ap.setAccuracy(50);
	ap.setName(name);
	ap.setPhone_number("75545455554");
	ap.setAddress(address);
	ap.setWebsite("www.ok.com");
	ap.setLanguage(language);
	List<String> s = new ArrayList<String>();
	s.add("One");
	s.add("Two");
	ap.setTypes(s);

	location l = new location();
	l.setLat(-34.056566);
	l.setLng(34.866646);
	ap.setLocation(l);
	return ap;	
	
	
}





}
