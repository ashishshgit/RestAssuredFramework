package resources;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class Utils {

	public static RequestSpecification req;

	public RequestSpecification request() throws IOException

	{
		if(req==null)
		{
		
		PrintStream log = new PrintStream(new FileOutputStream("loggging.txt"));

		req = new RequestSpecBuilder().setBaseUri(getGlobalValue("baseUrl")).addQueryParam("key", "qaclick23")
				.addFilter(RequestLoggingFilter.logRequestTo(log)).addFilter(ResponseLoggingFilter.logResponseTo(log))
				.setContentType(ContentType.JSON).build();
		return req;
		}

		return req;
	}

	public static String getGlobalValue(String key) throws IOException

	{

		Properties prop = new Properties();

		FileInputStream file = new FileInputStream(
				"C:\\Users\\FT-AS-1320\\eclipse-workspace\\BDDAPI\\src\\test\\java\\resources\\global.properties");
		prop.load(file);

		return prop.getProperty(key);

	}

}
