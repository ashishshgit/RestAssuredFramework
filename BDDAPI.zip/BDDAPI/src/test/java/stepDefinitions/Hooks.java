package stepDefinitions;

import java.io.IOException;

import io.cucumber.java.Before;

public class Hooks {
	
	// for define pre and post condition
	@Before("@DeletePlace")
	public void befeoreScenerio() throws IOException
	{
		// write a code that will give you place id
		
		//Execute the code only when place id null
		
		stepDefinitions sd = new stepDefinitions();
		
		sd.add_place_payload_with("ashish", "asa","asas");
		sd.user_call_with_http_request("AddPlaceApi", "Get");
		
	}

}
