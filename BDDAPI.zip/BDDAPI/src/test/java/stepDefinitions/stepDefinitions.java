package stepDefinitions;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.io.IOException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import resources.APIResources;
import resources.TestDataBuild;
import resources.Utils;

public class stepDefinitions extends Utils {

	RequestSpecification res;
	ResponseSpecification rp;
	Response rpe;

	TestDataBuild td = new TestDataBuild();

	@Given("Add place payload with {string} {string} {string}")
	public void add_place_payload_with(String name, String language, String address) throws IOException {

		res = given().spec(request()).body(td.AddPlcaePayload(name, language, address));
	}

	@When("user call {string} with {string} http request")
	public void user_call_with_http_request(String resource, String method) {
// constructor will be called with value of resource whch you pass\\\-
		APIResources apiresource = APIResources.valueOf(resource);
		System.out.println(apiresource.getResource());
		System.out.println(method);

		rp = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();

		if (method.equalsIgnoreCase("POST"))

			rpe = res.when().post(apiresource.getResource()).then().spec(rp).extract().response();
		else if (method.equalsIgnoreCase("GET"))
			rpe = res.when().get(apiresource.getResource());
		else {
			System.out.println("no method found");
		}
		System.out.println(rpe.getStatusCode());
	}

	@Then("the api call got sccuess with status code is {int}")
	public void the_api_call_got_sccuess_with_status_code_is(Integer int1) {

		assertEquals(rpe.getStatusCode(), 200);

	}

	@Then("{string} in response body is {string}")
	public void in_response_body_is(String key, String Expected) {

		String newrep = rpe.asString();

		JsonPath js = new JsonPath(newrep);
		String Actual = js.get(key);
		assertEquals(Actual, Expected);

	}

	@Given("DeletePlace Payload")
	public void delete_place_payload() {
	    
	
	
}
}
